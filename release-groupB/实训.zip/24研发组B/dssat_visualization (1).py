import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
from matplotlib import rcParams

rcParams['font.family'] = ['SimHei', 'Microsoft YaHei', 'Arial']
rcParams['font.size'] = 10
rcParams['axes.linewidth'] = 1.0
rcParams['lines.linewidth'] = 1.5
rcParams['lines.markersize'] = 4
rcParams['legend.fontsize'] = 9
rcParams['xtick.direction'] = 'in'
rcParams['ytick.direction'] = 'in'
rcParams['xtick.top'] = True
rcParams['ytick.right'] = True
rcParams['axes.unicode_minus'] = False

DSSAT_COLORS = {
    'python': '#1f77b4',
    'dssat': '#ff7f0e',
    'leaf': '#2ca02c',
    'stem': '#9467bd',
    'root': '#8c564b',
    'fruit': '#d62728',
    'total': '#17becf',
}


def load_data():
    daily_df = pd.read_csv(r'd:\桌面\1\Python_DSSAT_逐日交叉对比表.csv')
    final_df = pd.read_csv(r'd:\桌面\1\Python_DSSAT_最终指标对比.csv')
    phenology_df = pd.read_csv(r'd:\桌面\1\Python_DSSAT_物候期对比.csv')
    return daily_df, final_df, phenology_df


def plot_lai_comparison(daily_df):
    fig, ax = plt.subplots(figsize=(8, 5))
    
    ax.plot(daily_df['生长天数'], daily_df['Python_叶面积指数_LAI'], 
            color=DSSAT_COLORS['python'], linestyle='-', marker='o', 
            label='Python模型', markevery=5)
    ax.plot(daily_df['生长天数'], daily_df['DSSAT_叶面积指数_LAI'], 
            color=DSSAT_COLORS['dssat'], linestyle='--', marker='s', 
            label='DSSAT_Docker版', markevery=5)
    
    ax.set_xlabel('生长天数 (天)')
    ax.set_ylabel('叶面积指数 (LAI, m²/m²)')
    ax.set_title('叶面积指数对比')
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    fig.savefig(r'd:\桌面\LAI对比图.png', dpi=300, bbox_inches='tight')
    plt.close()


def plot_root_depth_comparison(daily_df):
    fig, ax = plt.subplots(figsize=(8, 5))
    
    ax.plot(daily_df['生长天数'], daily_df['Python_根系深度_cm'], 
            color=DSSAT_COLORS['python'], linestyle='-', marker='o', 
            label='Python模型', markevery=5)
    ax.plot(daily_df['生长天数'], daily_df['DSSAT_根系深度_cm'], 
            color=DSSAT_COLORS['dssat'], linestyle='--', marker='s', 
            label='DSSAT_Docker版', markevery=5)
    
    ax.set_xlabel('生长天数 (天)')
    ax.set_ylabel('根系深度 (cm)')
    ax.set_title('根系深度对比')
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    fig.savefig(r'd:\桌面\根系深度对比图.png', dpi=300, bbox_inches='tight')
    plt.close()


def plot_biomass_components(daily_df):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    ax1.plot(daily_df['生长天数'], daily_df['Python_总生物量'], 
             color=DSSAT_COLORS['total'], linestyle='-', label='总生物量')
    ax1.plot(daily_df['生长天数'], daily_df['Python_叶生物量'], 
             color=DSSAT_COLORS['leaf'], linestyle='--', label='叶生物量')
    ax1.plot(daily_df['生长天数'], daily_df['Python_茎生物量'], 
             color=DSSAT_COLORS['stem'], linestyle=':', label='茎生物量')
    ax1.plot(daily_df['生长天数'], daily_df['Python_根生物量'], 
             color=DSSAT_COLORS['root'], linestyle='-.', label='根生物量')
    
    ax1.set_xlabel('生长天数 (天)')
    ax1.set_ylabel('生物量 (g/株)')
    ax1.set_title('Python模型生物量分配')
    ax1.legend()
    ax1.grid(True, linestyle='--', alpha=0.7)
    
    ax2.plot(daily_df['生长天数'], daily_df['DSSAT_总干重'], 
             color=DSSAT_COLORS['total'], linestyle='-', label='总干重')
    ax2.plot(daily_df['生长天数'], daily_df['DSSAT_叶干重'], 
             color=DSSAT_COLORS['leaf'], linestyle='--', label='叶干重')
    ax2.plot(daily_df['生长天数'], daily_df['DSSAT_茎干重'], 
             color=DSSAT_COLORS['stem'], linestyle=':', label='茎干重')
    ax2.plot(daily_df['生长天数'], daily_df['DSSAT_根干重'], 
             color=DSSAT_COLORS['root'], linestyle='-.', label='根干重')
    
    ax2.set_xlabel('生长天数 (天)')
    ax2.set_ylabel('干重 (g/株)')
    ax2.set_title('DSSAT_Docker版干重分配')
    ax2.legend()
    ax2.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    fig.savefig(r'd:\桌面\生物量分配对比图.png', dpi=300, bbox_inches='tight')
    plt.close()


def plot_fruit_development(daily_df):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    ax1.plot(daily_df['生长天数'], daily_df['Python_果实数量_缺测'], 
             color=DSSAT_COLORS['fruit'], linestyle='-', marker='o', 
             markevery=5)
    ax1.set_xlabel('生长天数 (天)')
    ax1.set_ylabel('果实数量 (个/株)')
    ax1.set_title('Python模型果实数量')
    ax1.grid(True, linestyle='--', alpha=0.7)
    
    ax2.plot(daily_df['生长天数'], daily_df['Python_果实生物量_缺测'], 
             color=DSSAT_COLORS['fruit'], linestyle='-', marker='s', 
             markevery=5)
    ax2.set_xlabel('生长天数 (天)')
    ax2.set_ylabel('果实生物量 (g/株)')
    ax2.set_title('Python模型果实生物量')
    ax2.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    fig.savefig(r'd:\桌面\果实发育对比图.png', dpi=300, bbox_inches='tight')
    plt.close()


def plot_dssat_reproductive(daily_df):
    fig, ax = plt.subplots(figsize=(8, 5))
    
    ax.plot(daily_df['生长天数'], daily_df['DSSAT_生殖器官干重_缺测'], 
            color=DSSAT_COLORS['fruit'], linestyle='-', marker='o', 
            markevery=5, label='生殖器官干重')
    ax.plot(daily_df['生长天数'], daily_df['DSSAT_籽粒干重_缺测'], 
            color=DSSAT_COLORS['total'], linestyle='--', marker='s', 
            markevery=5, label='籽粒干重')
    
    ax.set_xlabel('生长天数 (天)')
    ax.set_ylabel('干重 (g/株)')
    ax.set_title('DSSAT生殖器官干重')
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    fig.savefig(r'd:\桌面\DSSAT生殖器官干重.png', dpi=300, bbox_inches='tight')
    plt.close()


def plot_final_metrics(final_df):
    common_metrics = final_df[final_df['指标类别'] == '共有指标']
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    metrics = common_metrics['指标名称'].tolist()
    python_values = common_metrics['Python模型'].tolist()
    dssat_values = common_metrics['DSSAT_Docker版'].tolist()
    
    x = np.arange(len(metrics))
    width = 0.35
    
    bars1 = ax1.bar(x - width/2, python_values, width, 
                    color=DSSAT_COLORS['python'], label='Python模型')
    bars2 = ax1.bar(x + width/2, dssat_values, width, 
                    color=DSSAT_COLORS['dssat'], label='DSSAT_Docker版')
    
    ax1.set_xlabel('指标名称')
    ax1.set_ylabel('数值')
    ax1.set_title('最终指标对比')
    ax1.set_xticks(x)
    ax1.set_xticklabels(metrics, rotation=30, ha='right')
    ax1.legend()
    
    for bars in [bars1, bars2]:
        for bar in bars:
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height,
                     f'{height:.2f}', ha='center', va='bottom', fontsize=8)
    
    diff_values = []
    for diff in common_metrics['差异'].tolist():
        if isinstance(diff, str) and '%' in diff:
            diff_values.append(float(diff.replace('%', '')))
        else:
            diff_values.append(0)
    
    ax2.bar(x, diff_values, width, color='#7f7f7f')
    ax2.axhline(y=0, color='black', linestyle='-', linewidth=1)
    ax2.set_xlabel('指标名称')
    ax2.set_ylabel('差异率 (%)')
    ax2.set_title('指标差异率')
    ax2.set_xticks(x)
    ax2.set_xticklabels(metrics, rotation=30, ha='right')
    
    for i, v in enumerate(diff_values):
        ax2.text(i, v, f'{v:.1f}%', ha='center', va='bottom' if v >= 0 else 'top', 
                 fontsize=8, color='red' if v < -50 else 'black')
    
    plt.tight_layout()
    fig.savefig(r'd:\桌面\最终指标对比图.png', dpi=300, bbox_inches='tight')
    plt.close()


def plot_phenology_comparison(phenology_df):
    python_stages = phenology_df[phenology_df['数据来源'] == 'Python模型']
    dssat_stages = phenology_df[phenology_df['数据来源'] == 'DSSAT_Docker版']
    
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)
    
    stage_names_python = python_stages['物候期名称'].tolist()
    start_days_python = python_stages['开始天数'].tolist()
    duration_python = python_stages['持续天数'].tolist()
    
    y_pos = np.arange(len(stage_names_python))
    ax1.barh(y_pos, duration_python, left=start_days_python, 
             color=DSSAT_COLORS['python'], alpha=0.7)
    
    ax1.set_yticks(y_pos)
    ax1.set_yticklabels(stage_names_python)
    ax1.set_xlabel('生长天数 (天)')
    ax1.set_title('Python模型物候期')
    ax1.grid(True, linestyle='--', alpha=0.7)
    ax1.invert_yaxis()
    
    stage_names_dssat = ['阶段0', '阶段1', '阶段2', '阶段5']
    start_days_dssat = dssat_stages['开始天数'].tolist()
    duration_dssat = dssat_stages['持续天数'].tolist()
    
    y_pos2 = np.arange(len(stage_names_dssat))
    ax2.barh(y_pos2, duration_dssat, left=start_days_dssat, 
             color=DSSAT_COLORS['dssat'], alpha=0.7)
    
    ax2.set_yticks(y_pos2)
    ax2.set_yticklabels(stage_names_dssat)
    ax2.set_xlabel('生长天数 (天)')
    ax2.set_title('DSSAT_Docker版生育阶段')
    ax2.grid(True, linestyle='--', alpha=0.7)
    ax2.invert_yaxis()
    
    plt.tight_layout()
    fig.savefig(r'd:\桌面\物候期对比图.png', dpi=300, bbox_inches='tight')
    plt.close()


def plot_phenology_timeline(daily_df):
    fig, ax = plt.subplots(figsize=(12, 6))
    
    ax.plot(daily_df['生长天数'], daily_df['Python_叶面积指数_LAI'], 
            color=DSSAT_COLORS['leaf'], linestyle='-', linewidth=2,
            label='LAI')
    ax.set_xlabel('生长天数 (天)')
    ax.set_ylabel('叶面积指数 (m²/m²)')
    ax.set_title('生长趋势与物候期标记')
    
    phenology_markers = {
        '萌发期': (1, '#1f77b4'),
        '出苗期': (4, '#ff7f0e'),
        '幼苗期': (8, '#2ca02c'),
        '营养生长期': (14, '#9467bd'),
        '花芽分化期': (27, '#d62728'),
        '开花期': (41, '#17becf'),
        '坐果期': (49, '#7f77b4'),
        '果实发育期': (57, '#bcbd22'),
        '果实成熟期': (75, '#e377c2'),
    }
    
    for stage, (day, color) in phenology_markers.items():
        ax.axvline(x=day, color=color, linestyle='--', alpha=0.6)
        ax.text(day, ax.get_ylim()[1] * 0.95, stage, 
                rotation=90, va='top', ha='right', fontsize=8, color=color)
    
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    fig.savefig(r'd:\桌面\生长趋势与物候期.png', dpi=300, bbox_inches='tight')
    plt.close()


def plot_multi_panel_summary(daily_df):
    fig, axs = plt.subplots(2, 3, figsize=(16, 10))
    
    axs[0, 0].plot(daily_df['生长天数'], daily_df['Python_叶面积指数_LAI'], 
                   color=DSSAT_COLORS['python'], linestyle='-', label='Python')
    axs[0, 0].plot(daily_df['生长天数'], daily_df['DSSAT_叶面积指数_LAI'], 
                   color=DSSAT_COLORS['dssat'], linestyle='--', label='DSSAT')
    axs[0, 0].set_xlabel('天数')
    axs[0, 0].set_ylabel('LAI')
    axs[0, 0].set_title('叶面积指数')
    axs[0, 0].legend(fontsize=8)
    axs[0, 0].grid(True, linestyle='--', alpha=0.7)
    
    axs[0, 1].plot(daily_df['生长天数'], daily_df['Python_根系深度_cm'], 
                   color=DSSAT_COLORS['python'], linestyle='-', label='Python')
    axs[0, 1].plot(daily_df['生长天数'], daily_df['DSSAT_根系深度_cm'], 
                   color=DSSAT_COLORS['dssat'], linestyle='--', label='DSSAT')
    axs[0, 1].set_xlabel('天数')
    axs[0, 1].set_ylabel('根系深度(cm)')
    axs[0, 1].set_title('根系深度')
    axs[0, 1].legend(fontsize=8)
    axs[0, 1].grid(True, linestyle='--', alpha=0.7)
    
    axs[0, 2].plot(daily_df['生长天数'], daily_df['Python_总生物量'], 
                   color=DSSAT_COLORS['python'], linestyle='-', label='Python')
    axs[0, 2].plot(daily_df['生长天数'], daily_df['DSSAT_总干重'], 
                   color=DSSAT_COLORS['dssat'], linestyle='--', label='DSSAT')
    axs[0, 2].set_xlabel('天数')
    axs[0, 2].set_ylabel('生物量(g/株)')
    axs[0, 2].set_title('总生物量')
    axs[0, 2].legend(fontsize=8)
    axs[0, 2].grid(True, linestyle='--', alpha=0.7)
    
    axs[1, 0].plot(daily_df['生长天数'], daily_df['Python_果实数量_缺测'], 
                   color=DSSAT_COLORS['fruit'], linestyle='-')
    axs[1, 0].set_xlabel('天数')
    axs[1, 0].set_ylabel('果实数量')
    axs[1, 0].set_title('果实数量(Python)')
    axs[1, 0].grid(True, linestyle='--', alpha=0.7)
    
    axs[1, 1].plot(daily_df['生长天数'], daily_df['Python_果实生物量_缺测'], 
                   color=DSSAT_COLORS['fruit'], linestyle='-')
    axs[1, 1].set_xlabel('天数')
    axs[1, 1].set_ylabel('果实生物量(g)')
    axs[1, 1].set_title('果实生物量(Python)')
    axs[1, 1].grid(True, linestyle='--', alpha=0.7)
    
    axs[1, 2].plot(daily_df['生长天数'], daily_df['DSSAT_生殖器官干重_缺测'], 
                   color=DSSAT_COLORS['fruit'], linestyle='-', label='生殖器官')
    axs[1, 2].plot(daily_df['生长天数'], daily_df['DSSAT_叶片数_缺测'], 
                   color=DSSAT_COLORS['leaf'], linestyle='--', label='叶片数')
    axs[1, 2].set_xlabel('天数')
    axs[1, 2].set_ylabel('干重/数量')
    axs[1, 2].set_title('DSSAT生殖器官与叶片')
    axs[1, 2].legend(fontsize=8)
    axs[1, 2].grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    fig.savefig(r'd:\桌面\生长趋势汇总图.png', dpi=300, bbox_inches='tight')
    plt.close()


def plot_dssat_specific_metrics(daily_df):
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 12))
    
    ax1.plot(daily_df['生长天数'], daily_df['DSSAT_冠层高度_缺测'], 
             color=DSSAT_COLORS['python'], linestyle='-', marker='o', markevery=5)
    ax1.set_xlabel('生长天数 (天)')
    ax1.set_ylabel('冠层高度 (cm)')
    ax1.set_title('DSSAT冠层高度')
    ax1.grid(True, linestyle='--', alpha=0.7)
    
    ax2.plot(daily_df['生长天数'], daily_df['DSSAT_冠层宽度_缺测'], 
             color=DSSAT_COLORS['dssat'], linestyle='--', marker='s', markevery=5)
    ax2.set_xlabel('生长天数 (天)')
    ax2.set_ylabel('冠层宽度 (cm)')
    ax2.set_title('DSSAT冠层宽度')
    ax2.grid(True, linestyle='--', alpha=0.7)
    
    ax3.plot(daily_df['生长天数'], daily_df['DSSAT_收获指数_缺测'], 
             color=DSSAT_COLORS['total'], linestyle=':', marker='^', markevery=5)
    ax3.set_xlabel('生长天数 (天)')
    ax3.set_ylabel('收获指数')
    ax3.set_title('DSSAT收获指数')
    ax3.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    fig.savefig(r'd:\桌面\DSSAT特有指标图.png', dpi=300, bbox_inches='tight')
    plt.close()


def main():
    daily_df, final_df, phenology_df = load_data()
    
    print("正在生成LAI对比图...")
    plot_lai_comparison(daily_df)
    
    print("正在生成根系深度对比图...")
    plot_root_depth_comparison(daily_df)
    
    print("正在生成生物量分配对比图...")
    plot_biomass_components(daily_df)
    
    print("正在生成果实发育对比图...")
    plot_fruit_development(daily_df)
    
    print("正在生成DSSAT生殖器官干重图...")
    plot_dssat_reproductive(daily_df)
    
    print("正在生成最终指标对比图...")
    plot_final_metrics(final_df)
    
    print("正在生成物候期对比图...")
    plot_phenology_comparison(phenology_df)
    
    print("正在生成生长趋势与物候期图...")
    plot_phenology_timeline(daily_df)
    
    print("正在生成生长趋势汇总图...")
    plot_multi_panel_summary(daily_df)
    
    print("正在生成DSSAT特有指标图...")
    plot_dssat_specific_metrics(daily_df)
    
    print("所有图表已生成完成！")


if __name__ == "__main__":
    main()