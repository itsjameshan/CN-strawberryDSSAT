/**
 * 农业参数组模块 - 负责农业参数配置、阈值设定、知识库
 * 
 * 【接口契约 - 请农业参数组实现以下函数】
 * 
 * @interface AgriGroupInterface
 * @method init() - 初始化农业参数，在页面加载时调用
 * @method getThresholds() - 获取各指标阈值配置
 *   @returns {Object} - 阈值配置
 *     @property {Object} temperature - 温度阈值
 *       @property {number} min - 最小值
 *       @property {number} max - 最大值
 *       @property {number} warningMin - 警告下限
 *       @property {number} warningMax - 警告上限
 *     @property {Object} humidity - 湿度阈值(同上)
 *     @property {Object} co2 - CO₂阈值(同上)
 *     @property {Object} light - 光照阈值(同上)
 *     @property {Object} soilMoisture - 土壤湿度阈值(同上)
 *     @property {Object} soilPh - 土壤pH阈值(同上)
 * 
 * @method getVarieties() - 获取草莓品种信息
 *   @returns {Array} - 品种列表
 *     @property {string} name - 品种名称
 *     @property {string} idealTemp - 适宜温度范围
 *     @property {string} idealHumidity - 适宜湿度范围
 *     @property {string} description - 品种描述
 * 
 * @method getPlantingSpecs() - 获取种植规范
 *   @returns {Array} - 规范列表
 *     @property {string} name - 规范名称
 *     @property {string} value - 规范值
 *     @property {string} unit - 单位
 * 
 * @method getExpertAdvice(data) - 获取专家建议
 *   @param {Object} data - 当前传感器数据
 *   @returns {Object} - 建议结果
 *     @property {string} level - 建议级别(正常/注意/警告)
 *     @property {string} title - 建议标题
 *     @property {string} content - 建议内容
 *     @property {Array} actions - 推荐操作列表
 */

const AgriGroup = {
    name: 'AgriGroup',
    
    init() {
        console.log('[AgriGroup] 初始化完成 - 农业参数接口已就绪');
        EventBus.emit('agri-ready', { group: 'agri', timestamp: Date.now() });
    },

    getThresholds() {
        return {
            temperature: { min: 15, max: 28, warningMin: 17, warningMax: 26 },
            humidity: { min: 50, max: 85, warningMin: 55, warningMax: 80 },
            co2: { min: 400, max: 1200, warningMin: 500, warningMax: 1000 },
            light: { min: 500, max: 2000, warningMin: 600, warningMax: 1800 },
            soilMoisture: { min: 40, max: 70, warningMin: 45, warningMax: 65 },
            soilPh: { min: 5.0, max: 7.0, warningMin: 5.5, warningMax: 6.5 }
        };
    },

    getVarieties() {
        return [
            { name: '红颜草莓', idealTemp: '15-25°C', idealHumidity: '60-80%', description: '果实大、色泽鲜艳、口感香甜' },
            { name: '章姬草莓', idealTemp: '16-26°C', idealHumidity: '65-85%', description: '果肉细嫩、香气浓郁、产量高' },
            { name: '丰香草莓', idealTemp: '15-24°C', idealHumidity: '55-75%', description: '早熟品种、适应性强、抗病性好' },
            { name: '甜查理草莓', idealTemp: '18-30°C', idealHumidity: '60-80%', description: '耐高温、耐储运、适合南方种植' }
        ];
    },

    getPlantingSpecs() {
        return [
            { name: '定植密度', value: '8000-10000', unit: '株/亩' },
            { name: '行距', value: '25-30', unit: '厘米' },
            { name: '株距', value: '15-20', unit: '厘米' },
            { name: '定植时间', value: '9-10', unit: '月' },
            { name: '采收周期', value: '30-40', unit: '天' },
            { name: '亩产量', value: '3000-5000', unit: '公斤' }
        ];
    },

    getExpertAdvice(data) {
        const thresholds = this.getThresholds();
        let issues = [];
        
        if (data.temperature < thresholds.temperature.warningMin) {
            issues.push({ field: '温度', issue: '偏低', action: '建议提高大棚温度' });
        } else if (data.temperature > thresholds.temperature.warningMax) {
            issues.push({ field: '温度', issue: '偏高', action: '建议加强通风降温' });
        }
        
        if (data.humidity < thresholds.humidity.warningMin) {
            issues.push({ field: '湿度', issue: '偏低', action: '建议开启加湿设备' });
        } else if (data.humidity > thresholds.humidity.warningMax) {
            issues.push({ field: '湿度', issue: '偏高', action: '建议加强通风降湿' });
        }
        
        if (data.co2 > thresholds.co2.warningMax) {
            issues.push({ field: 'CO₂', issue: '浓度过高', action: '建议加强通风换气' });
        }
        
        if (issues.length === 0) {
            return {
                level: '正常',
                title: '环境参数良好',
                content: '当前大棚各项环境参数处于适宜范围，草莓生长状况良好。',
                actions: ['继续保持当前环境条件', '定期监测各项指标', '注意观察植株生长状态']
            };
        } else {
            return {
                level: issues.length > 2 ? '警告' : '注意',
                title: `检测到 ${issues.length} 项参数异常`,
                content: issues.map(i => `${i.field}${i.issue}`).join('；') + '。',
                actions: issues.map(i => i.action)
            };
        }
    }
};
