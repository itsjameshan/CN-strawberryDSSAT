/**
 * 可视化组模块 - 负责图表渲染、数据可视化
 * 
 * 【接口契约 - 请可视化组实现以下函数】
 * 
 * @interface ChartGroupInterface
 * @method init() - 初始化图表，在页面加载时调用
 * @method renderLineChart(containerId, data, config) - 渲染折线图
 *   @param {string} containerId - DOM容器ID
 *   @param {Array} data - 历史数据数组
 *     @property {string} time - 时间标签
 *     @property {number} temperature - 温度值
 *     @property {number} humidity - 湿度值
 *     @property {number} co2 - CO₂值
 *     @property {number} light - 光照值
 *   @param {Object} config - 图表配置
 *     @property {string} title - 图表标题
 *     @property {Array} labels - 显示的指标列表
 *     @property {string} xAxisLabel - X轴标签
 *     @property {string} yAxisLabel - Y轴标签
 * 
 * @method renderBarChart(containerId, data, config) - 渲染柱状图
 *   @param {string} containerId - DOM容器ID
 *   @param {Array} data - 数据数组
 *   @param {Object} config - 图表配置
 * 
 * @method renderGaugeChart(containerId, value, config) - 渲染仪表盘
 *   @param {string} containerId - DOM容器ID
 *   @param {number} value - 当前值
 *   @param {Object} config - 配置
 *     @property {number} min - 最小值
 *     @property {number} max - 最大值
 *     @property {string} label - 标签
 *     @property {string} unit - 单位
 *     @property {string} color - 颜色
 * 
 * @method updateChart(chartId, newData) - 更新已有图表数据
 *   @param {string} chartId - 图表ID
 *   @param {Object} newData - 新数据
 */

const ChartGroup = {
    name: 'ChartGroup',
    charts: {},
    
    init() {
        console.log('[ChartGroup] 初始化完成 - 可视化接口已就绪');
        EventBus.emit('chart-ready', { group: 'chart', timestamp: Date.now() });
    },

    renderLineChart(containerId, data, config) {
        console.log('[ChartGroup] 渲染折线图:', containerId, config.title);
        const container = document.getElementById(containerId);
        if (!container) return;

        const labels = data.map(d => d.time);
        const datasets = (config.labels || ['temperature']).map(label => ({
            label: this._getLabelName(label),
            data: data.map(d => d[label]),
            borderColor: this._getColor(label),
            backgroundColor: this._getColor(label) + '20',
            tension: 0.4,
            fill: true
        }));

        if (window.Chart) {
            if (this.charts[containerId]) {
                this.charts[containerId].destroy();
            }
            this.charts[containerId] = new Chart(container, {
                type: 'line',
                data: { labels, datasets },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: { display: true, text: config.title, font: { size: 14 } },
                        legend: { position: 'bottom' }
                    },
                    scales: {
                        x: { title: { display: true, text: config.xAxisLabel || '时间' } },
                        y: { title: { display: true, text: config.yAxisLabel || '数值' } }
                    }
                }
            });
        } else {
            container.innerHTML = `<div class="chart-placeholder">📊 ${config.title}<br/>数据点: ${data.length}</div>`;
        }
    },

    renderBarChart(containerId, data, config) {
        console.log('[ChartGroup] 渲染柱状图:', containerId, config.title);
        const container = document.getElementById(containerId);
        if (!container) return;

        if (window.Chart) {
            if (this.charts[containerId]) {
                this.charts[containerId].destroy();
            }
            this.charts[containerId] = new Chart(container, {
                type: 'bar',
                data: {
                    labels: data.map(d => d.label),
                    datasets: [{
                        label: config.valueLabel || '数值',
                        data: data.map(d => d.value),
                        backgroundColor: config.colors || ['#e74c3c', '#27ae60', '#3498db', '#f39c12', '#9b59b6']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: { display: true, text: config.title, font: { size: 14 } }
                    }
                }
            });
        } else {
            container.innerHTML = `<div class="chart-placeholder">📊 ${config.title}<br/>数据点: ${data.length}</div>`;
        }
    },

    renderGaugeChart(containerId, value, config) {
        console.log('[ChartGroup] 渲染仪表盘:', containerId, value);
        const container = document.getElementById(containerId);
        if (!container) return;

        const percentage = ((value - config.min) / (config.max - config.min)) * 100;
        container.innerHTML = `
            <div class="gauge-container">
                <div class="gauge-value">${value.toFixed(1)}</div>
                <div class="gauge-unit">${config.unit}</div>
                <div class="gauge-bar">
                    <div class="gauge-fill" style="width: ${Math.min(100, Math.max(0, percentage))}%; background: ${config.color}"></div>
                </div>
                <div class="gauge-label">${config.label}</div>
            </div>
        `;
    },

    updateChart(chartId, newData) {
        console.log('[ChartGroup] 更新图表:', chartId);
        if (this.charts[chartId]) {
            this.charts[chartId].update('none');
        }
    },

    _getLabelName(key) {
        const map = { temperature: '温度', humidity: '湿度', co2: 'CO₂', light: '光照', soilMoisture: '土壤湿度' };
        return map[key] || key;
    },

    _getColor(key) {
        const map = { temperature: '#e74c3c', humidity: '#3498db', co2: '#f39c12', light: '#f1c40f', soilMoisture: '#27ae60' };
        return map[key] || '#95a5a6';
    }
};
