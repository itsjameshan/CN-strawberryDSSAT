/**
 * 发布组模块 - 负责网页框架构建、UI渲染、页面布局
 * 
 * 【接口契约 - 本文件由发布组维护】
 * 
 * 挂载点说明：
 * - #sensor-panel - 传感器数据展示区
 * - #chart-section - 图表展示区
 * - #model-result - 模型预测结果区
 * - #agri-info - 农业参数展示区
 * - #alert-section - 告警信息区
 * - #case-study - 案例展示区
 * 
 * 事件监听：
 * - sensor-data-updated - 传感器数据更新事件
 * - yield-predicted - 产量预测完成事件
 * - disease-detected - 病虫害检测完成事件
 * - harvest-forecasted - 采收预测完成事件
 * - expert-advice-updated - 专家建议更新事件
 */

const PublishGroup = {
    name: 'PublishGroup',
    
    init() {
        console.log('[PublishGroup] 初始化完成 - 发布组接口已就绪');
        this._setupEventListeners();
        EventBus.emit('publish-ready', { group: 'publish', timestamp: Date.now() });
    },

    renderSensorPanel(data) {
        const panel = document.getElementById('sensor-panel');
        if (!panel) return;

        const sensorConfig = [
            { key: 'temperature', label: '温度', unit: '°C', icon: '🌡️', color: '#e74c3c' },
            { key: 'humidity', label: '湿度', unit: '%', icon: '💧', color: '#3498db' },
            { key: 'co2', label: 'CO₂', unit: 'ppm', icon: '🌬️', color: '#f39c12' },
            { key: 'light', label: '光照', unit: 'lux', icon: '☀️', color: '#f1c40f' },
            { key: 'soilMoisture', label: '土壤湿度', unit: '%', icon: '🌱', color: '#27ae60' },
            { key: 'soilPh', label: '土壤pH', unit: '', icon: '🧪', color: '#9b59b6' }
        ];

        panel.innerHTML = sensorConfig.map(sensor => {
            const value = data[sensor.key];
            const thresholds = AgriGroup.getThresholds()[sensor.key];
            let status = 'normal';
            if (value < thresholds.warningMin || value > thresholds.warningMax) {
                status = 'warning';
            }
            if (value < thresholds.min || value > thresholds.max) {
                status = 'danger';
            }
            
            return `
                <div class="sensor-card ${status}" style="--accent-color: ${sensor.color}">
                    <div class="sensor-icon">${sensor.icon}</div>
                    <div class="sensor-info">
                        <div class="sensor-label">${sensor.label}</div>
                        <div class="sensor-value">${value !== undefined ? value.toFixed(1) : '--'}<span class="sensor-unit">${sensor.unit}</span></div>
                    </div>
                    <div class="sensor-status">
                        <span class="status-dot ${status}"></span>
                    </div>
                </div>
            `;
        }).join('');
    },

    renderModelResults(results) {
        const container = document.getElementById('model-result');
        if (!container) return;

        container.innerHTML = `
            <div class="model-card">
                <h3 class="card-title">📈 产量预测</h3>
                <div class="model-value">${results.yield ? results.yield.toFixed(0) : '--'} <span class="model-unit">kg/亩</span></div>
                <div class="model-detail">置信度: ${results.confidence ? (results.confidence * 100).toFixed(0) + '%' : '--'} | 品质: ${results.grade || '--'}</div>
            </div>
            <div class="model-card">
                <h3 class="card-title">🕐 采收预测</h3>
                <div class="model-value">${results.daysToHarvest || '--'} <span class="model-unit">天</span></div>
                <div class="model-detail">预计采收: ${results.harvestDate || '--'}</div>
            </div>
            <div class="model-card ${results.hasDisease ? 'warning' : ''}">
                <h3 class="card-title">🦠 病虫害检测</h3>
                <div class="model-value">${results.hasDisease ? '⚠️ 异常' : '✅ 正常'}</div>
                <div class="model-detail">${results.hasDisease ? results.diseaseName + ' ' + (results.probability * 100).toFixed(0) + '%' : '未检测到病虫害'}</div>
            </div>
        `;
    },

    renderExpertAdvice(advice) {
        const container = document.getElementById('expert-advice');
        if (!container) return;

        const levelColors = { '正常': '#27ae60', '注意': '#f39c12', '警告': '#e74c3c' };
        
        container.innerHTML = `
            <div class="advice-card" style="border-left-color: ${levelColors[advice.level]}">
                <div class="advice-header">
                    <span class="advice-level" style="background: ${levelColors[advice.level]}">${advice.level}</span>
                    <h3 class="advice-title">${advice.title}</h3>
                </div>
                <p class="advice-content">${advice.content}</p>
                <ul class="advice-actions">
                    ${advice.actions.map(action => `<li>• ${action}</li>`).join('')}
                </ul>
            </div>
        `;
    },

    renderAlertSection(alerts) {
        const container = document.getElementById('alert-section');
        if (!container) return;

        if (alerts.length === 0) {
            container.innerHTML = '<div class="alert-empty">✅ 暂无告警信息</div>';
            return;
        }

        container.innerHTML = `
            <h3 class="section-title">⚠️ 告警信息</h3>
            <div class="alert-list">
                ${alerts.map((alert, index) => `
                    <div class="alert-item ${alert.level}">
                        <span class="alert-time">${alert.time}</span>
                        <span class="alert-message">${alert.message}</span>
                    </div>
                `).join('')}
            </div>
        `;
    },

    _setupEventListeners() {
        EventBus.on('sensor-data-updated', (data) => {
            this.renderSensorPanel(data);
        });

        EventBus.on('yield-predicted', (result) => {
            const currentResults = this._getCurrentModelResults();
            this.renderModelResults({ ...currentResults, ...result });
        });

        EventBus.on('disease-detected', (result) => {
            const currentResults = this._getCurrentModelResults();
            this.renderModelResults({ ...currentResults, ...result });
        });

        EventBus.on('harvest-forecasted', (result) => {
            const currentResults = this._getCurrentModelResults();
            this.renderModelResults({ ...currentResults, ...result });
        });

        EventBus.on('expert-advice-updated', (advice) => {
            this.renderExpertAdvice(advice);
        });
    },

    _getCurrentModelResults() {
        return {};
    }
};
