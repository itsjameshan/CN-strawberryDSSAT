const DataAdapter = {
    config: {
        useMockData: true,
        apiBaseUrl: 'http://localhost:8080/api'
    },
    mockData: {
        sensors: {
            temperature: 22.5,
            humidity: 65,
            co2: 800,
            light: 1200,
            soilMoisture: 55,
            soilPh: 6.0
        },
        forecast: {
            yield: 3500,
            daysToHarvest: 15,
            quality: '优'
        },
        history: []
    },
    async getSensorData() {
        if (this.config.useMockData) {
            const hour = new Date().getHours();
            const tempBase = hour >= 6 && hour <= 18 ? 24 : 18;
            const humidityBase = hour >= 6 && hour <= 18 ? 60 : 75;
            return {
                temperature: tempBase + (Math.random() - 0.5) * 4,
                humidity: humidityBase + (Math.random() - 0.5) * 10,
                co2: 700 + Math.random() * 300,
                light: hour >= 6 && hour <= 18 ? 800 + Math.random() * 600 : Math.random() * 50,
                soilMoisture: 50 + Math.random() * 10,
                soilPh: 5.5 + Math.random() * 1
            };
        } else {
            const response = await fetch(`${this.config.apiBaseUrl}/sensors`);
            return response.json();
        }
    },
    async getForecastData() {
        if (this.config.useMockData) {
            return this.mockData.forecast;
        } else {
            const response = await fetch(`${this.config.apiBaseUrl}/forecast`);
            return response.json();
        }
    },
    async getHistoryData(hours = 24) {
        if (this.config.useMockData) {
            const data = [];
            for (let i = hours; i >= 0; i--) {
                const date = new Date();
                date.setHours(date.getHours() - i);
                const hour = date.getHours();
                const tempBase = hour >= 6 && hour <= 18 ? 24 : 18;
                data.push({
                    time: `${hour.toString().padStart(2, '0')}:00`,
                    temperature: tempBase + (Math.random() - 0.5) * 3,
                    humidity: (hour >= 6 && hour <= 18 ? 60 : 75) + (Math.random() - 0.5) * 8,
                    co2: 750 + Math.random() * 200,
                    light: hour >= 6 && hour <= 18 ? 900 + Math.random() * 500 : Math.random() * 40
                });
            }
            return data;
        } else {
            const response = await fetch(`${this.config.apiBaseUrl}/history?hours=${hours}`);
            return response.json();
        }
    },
    switchToRealData(apiUrl) {
        this.config.useMockData = false;
        if (apiUrl) {
            this.config.apiBaseUrl = apiUrl;
        }
        console.log('[DataAdapter] Switched to real API data:', this.config.apiBaseUrl);
    },
    switchToMockData() {
        this.config.useMockData = true;
        console.log('[DataAdapter] Switched to mock data');
    }
};
